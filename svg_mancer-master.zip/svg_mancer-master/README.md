# svg_mancer
A tool for making SVG graphics on the web.
